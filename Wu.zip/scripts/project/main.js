runOnStartup(async runtime => {
	runtime.addEventListener("beforeprojectstart", () => OnBeforeProjectStart(runtime));
});

async function OnBeforeProjectStart(runtime) {
	runtime.addEventListener("tick", () => Tick(runtime));
}

const debug = (runtime) => {
	const debugElement = document.querySelector("#debug")
	const updateDebugContent = (id, value) => debugElement.querySelector(id).innerHTML = value
	const playerInstance = runtime.objects.Player.getFirstInstance()
	console.log(playerInstance)
	updateDebugContent('#bastionScaleY', `bastionScaleY: ${runtime.globalVars.bastionScaleY}`)
	updateDebugContent('#bastionHeight', `bastionHeight: ${runtime.globalVars.bastionHeight}`)
	updateDebugContent('#pullForce', `pullForce: ${runtime.globalVars.pullForce}`)
	updateDebugContent("#pullEnabled", `is pull enabled: ${runtime.globalVars.pullEnabled ? 'true' : 'false'}`)
	updateDebugContent("#coords", `y:${playerInstance.y} x:${playerInstance.x} angle: ${(playerInstance.angle * 180) / Math.PI}`)
}


function Tick(runtime) {
//     console.log(runtime.objects.Player.getFirstInstance().angle * 180 / Math.PI)
// 	console.log(runtime.objects.Player.instance())
	debug(runtime)
}
